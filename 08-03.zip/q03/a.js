
for(var i=1 ; i < 6 ; i = i+1 )
    {
        document.write("<img src ='cat.jpg'>");

        document.write("<hr>")
    }

