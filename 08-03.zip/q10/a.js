for(var i=1; i<=10; i=i+1){
    document.write(i)
}