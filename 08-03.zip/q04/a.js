for(var i=1 ; i <= 5 ; i = i + 1 ){
    document.write("<img src='cat.jpg'>");
}