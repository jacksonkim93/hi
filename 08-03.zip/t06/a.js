var random;
random = Math.floor(Math.random() * 100) + 1; 

for(var i=1 ; i <= random ; i = i + 1 ){
    document.write("<img src='cat.jpg'>")
    document.write(i);
}
