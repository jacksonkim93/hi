window.onload = function() {

    var random = Math.floor(Math.random() *20) +1;

    for(var i=1; i <= random; i=i+1) {


        if(i == 7){
            document.write("<img id='goldcat' src='cat.jpg'>");
            document.write(i);

            var cat = document.getElementById("goldcat");
            cat.style.borderStyle = "solid";
            cat.style.borderColor = "yellow";
            cat.style.borderWidth = "10px";
            cat.style.borderRadius = "20px";
            
            
        } else {
            document.write("<img src='cat.jpg' style='border-style: solid; border-color: black; border-width: 10px; border-radius: 20px;'>");
            document.write(i);
        }
    }
}