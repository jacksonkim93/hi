var a=1;
var b=2;

var c = a + b;

document.write("개")
x();
document.write("고양이")
x();
document.write("너굴맨")
document.write(c);
if(b>1){
    document.write(c);
    document.write(c);
    document.write(c);
    document.write(c);
}

document.write(c);
document.write(c);
document.write(c);

function x(){
    document.write(c)
}