function addCatAndInputText(){
    var inputText = prompt("값 입력:");
    document.write("고양이"+inputText);
}

addCatAndInputText();