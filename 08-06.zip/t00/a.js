function x(){
    document.write("<br>");
}

function x1(){
    document.write("<hr>")
}

document.write("고양이");
x();
x1();
document.write("고양이");
x();
x1();
document.write("고양이");
x();
x1();