var p = [0,0,0,0,0,0];

p[0] = 1;
p[1] = 2;
p[2] = 3;
p[3] = 4;
p[4] = 5;
p[5] = 6;

var r1,r2,r3,r4,r5,r6;

r1 = Math.floor(Math.random() * 45) + 1;
document.write(r1);
document.write("<br>");

while(true){

    r2 = Math.floor(Math.random() * 45) + 1;

    if(r1 != r2){
        document.write(r2);
        document.write("<br>");
        break;
    }
}

while(true){

    r3 = Math.floor(Math.random() * 45) + 1;

    if(r3 != r1 && r3 != r2){
        document.write(r3);
        document.write("<br>");
        break;
    }
}

while(true){

    r4 = Math.floor(Math.random() * 45) + 1;

    if(r4 != r1 && r4 != r2 && r4 != r3){
        document.write(r4);
        document.write("<br>");
        break;
    }
}

while(true){

    r5 = Math.floor(Math.random() * 45) + 1;

    if(r5 != r1 && r5 != r2 && r5 != r3 && r5 != r4){
        document.write(r5);
        document.write("<br>");
        break;
    }
}

while(true){

    r6 = Math.floor(Math.random() * 45) + 1;

    if(r6 != r1 && r6 != r2 && r6 != r3 && r6 != r4 && r6 != r5){
        document.write(r6);
        document.write("<br>");
        break;
    }
}


var win = 0;

if(p[0] == r1){
    win = win + 1
}
if(p[0] == r2){
    win = win + 1
}
if(p[0] == r3){
    win = win + 1
}
if(p[0] == r4){
    win = win + 1
}
if(p[0] == r5){
    win = win + 1
}
if(p[0] == r6){
    win = win + 1
}

if(p[1] == r1){
    win = win + 1
}
if(p[1] == r2){
    win = win + 1
}
if(p[1] == r3){
    win = win + 1
}
if(p[1] == r4){
    win = win + 1
}
if(p[1] == r5){
    win = win + 1
}
if(p[1] == r6){
    win = win + 1
}

if(p[2] == r1){
    win = win + 1
}
if(p[2] == r2){
    win = win + 1
}
if(p[2] == r3){
    win = win + 1
}
if(p[2] == r4){
    win = win + 1
}
if(p[2] == r5){
    win = win + 1
}
if(p[2] == r6){
    win = win + 1
}

if(p[3] == r1){
    win = win + 1
}
if(p[3] == r2){
    win = win + 1
}
if(p[3] == r3){
    win = win + 1
}
if(p[3] == r4){
    win = win + 1
}
if(p[3] == r5){
    win = win + 1
}
if(p[3] == r6){
    win = win + 1
}

if(p[4] == r1){
    win = win + 1
}
if(p[4] == r2){
    win = win + 1
}
if(p[4] == r3){
    win = win + 1
}
if(p[4] == r4){
    win = win + 1
}
if(p[4] == r5){
    win = win + 1
}
if(p[4] == r6){
    win = win + 1
}

if(p[5] == r1){
    win = win + 1
}
if(p[5] == r2){
    win = win + 1
}
if(p[5] == r3){
    win = win + 1
}
if(p[5] == r4){
    win = win + 1
}
if(p[5] == r5){
    win = win + 1
}
if(p[5] == r6){
    win = win + 1
}

document.write("win:"+win);