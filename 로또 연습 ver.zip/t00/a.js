var p1 = 1;
var p1 = 2;
var p1 = 3;
var p1 = 4;
var p1 = 5;
var p1 = 6;

var r1 = Math.floor(Math.random() * 45) + 1;
document.write(r1);
document.write("<br>");

var r2 = Math.floor(Math.random() * 45) + 1;
document.write(r2);
document.write("<br>");

var r3 = Math.floor(Math.random() * 45) + 1;
document.write(r3);
document.write("<br>");

var r4 = Math.floor(Math.random() * 45) + 1;
document.write(r4);
document.write("<br>");

var r5 = Math.floor(Math.random() * 45) + 1;
document.write(r5);
document.write("<br>");

var r6 = Math.floor(Math.random() * 45) + 1;
document.write(r6);
document.write("<br>");
