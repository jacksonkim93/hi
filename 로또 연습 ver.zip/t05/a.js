var p = [0, 0, 0, 0, 0, 0];

p[0] = 1;
p[1] = 2;
p[2] = 3;
p[3] = 4;
p[4] = 5;
p[5] = 6;

var r = [0, 0, 0, 0, 0, 0];


r[0] = Math.floor(Math.random() * 45) + 1;
document.write(r[0]);
document.write("<br>");


while (true) {

    r[1] = Math.floor(Math.random() * 45) + 1;
    if (r[0] != r[1]) {
        document.write(r[1]);
        document.write("<br>");
        break;
    }
}


while (true) {

    r[2] = Math.floor(Math.random() * 45) + 1;
    if (r[2] != r[0] && r[2] != r[1]) {
        document.write(r[2]);
        document.write("<br>");
        break;
    }
}


while (true) {

    r[3] = Math.floor(Math.random() * 45) + 1;
    if (r[3] != r[0] && r[3] != r[1] && r[3] != r[2]) {
        document.write(r[3]);
        document.write("<br>");
        break;
    }
}


while (true) {

    r[4] = Math.floor(Math.random() * 45) + 1;
    if (r[4] != r[0] && r[4] != r[1] && r[4] != r[2] && r[4] != r[3]) {
        document.write(r[4]);
        document.write("<br>");
        break;
    }
}


while (true) {

    r[5] = Math.floor(Math.random() * 45) + 1;
    if (r[5] != r[0] && r[5] != r[1] && r[5] != r[2] && r[5] != r[3] && r[5] != r[4]) {
        document.write(r[5]);
        document.write("<br>");
        break;
    }
}


if (p[0] == r[0]) {
    win = win + 1;
}
if (p[0] == r[1]) {
    win = win + 1;
}
if (p[0] == r[2]) {
    win = win + 1;
}
if (p[0] == r[3]) {
    win = win + 1;
}
if (p[0] == r[4]) {
    win = win + 1;
}
if (p[0] == r[5]) {
    win = win + 1;
}

if (p[1] == r[0]) {
    win = win + 1;
}
if (p[1] == r[1]) {
    win = win + 1;
}
if (p[1] == r[2]) {
    win = win + 1;
}
if (p[1] == r[3]) {
    win = win + 1;
}
if (p[1] == r[4]) {
    win = win + 1;
}
if (p[1] == r[5]) {
    win = win + 1;
}

if (p[2] == r[0]) {
    win = win + 1;
}
if (p[2] == r[1]) {
    win = win + 1;
}
if (p[2] == r[2]) {
    win = win + 1;
}
if (p[2] == r[3]) {
    win = win + 1;
}
if (p[2] == r[4]) {
    win = win + 1;
}
if (p[2] == r[5]) {
    win = win + 1;
}

if (p[3] == r[0]) {
    win = win + 1;
}
if (p[3] == r[1]) {
    win = win + 1;
}
if (p[3] == r[2]) {
    win = win + 1;
}
if (p[3] == r[3]) {
    win = win + 1;
}
if (p[3] == r[4]) {
    win = win + 1;
}
if (p[3] == r[5]) {
    win = win + 1;
}

if (p[4] == r[0]) {
    win = win + 1;
}
if (p[4] == r[1]) {
    win = win + 1;
}
if (p[4] == r[2]) {
    win = win + 1;
}
if (p[4] == r[3]) {
    win = win + 1;
}
if (p[4] == r[4]) {
    win = win + 1;
}
if (p[4] == r[5]) {
    win = win + 1;
}

if (p[5] == r[0]) {
    win = win + 1;
}
if (p[5] == r[1]) {
    win = win + 1;
}
if (p[5] == r[2]) {
    win = win + 1;
}
if (p[5] == r[3]) {
    win = win + 1;
}
if (p[5] == r[4]) {
    win = win + 1;
}
if (p[5] == r[5]) {
    win = win + 1;
}

document.write("win:" + win);
