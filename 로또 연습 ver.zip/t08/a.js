var tagResult;
var winNumbers = new Array();

var t;
var resultText = "";
var p = [1, 2, 3, 4, 5, 6];
var r = [0, 0, 0, 0, 0, 0];

var a1
var a2
var a3
var a4
var a5
var a6
window.onload = function () {
    t = document.getElementById("t");
    a1 = document.getElementById("a1");
    a2 = document.getElementById("a2");
    a3 = document.getElementById("a3");
    a4 = document.getElementById("a4");
    a5 = document.getElementById("a5");
    a6 = document.getElementById("a6");
    tagResult = document.getElementById("result");

}

function insertPlayerLotto() {
    p[0] = a1.value;
    p[1] = a2.value;
    p[2] = a3.value;
    p[3] = a4.value;
    p[4] = a5.value;
    p[5] = a6.value;
}

function checkLottoNumberDuplicates() {
    var isDuplicated = false;
    for (var i = 0; i < 5; i++) {
        for (var j = i + 1; j <= 5; j++) {
            if (p[i] == p[j]) {
                isDuplicated = true
            }
        }
    }
    return isDuplicated
}

function runLotto() {
    resultText = "";
    winNumbers = [];

    insertPlayerLotto();

    var isPlayerLottoDuplicated = checkLottoNumberDuplicates();
    log(isPlayerLottoDuplicated);
    if (isPlayerLottoDuplicated) {
        t.value = "장난x";
        return;

    }

    resultTextADD("유저: \n")
    for (var i = 0; i <= 5; i = i + 1) {
        resultTextADD(p[i] + "\n");
    }
    resultTextADD("당첨번호:\n")

    r[0] = Math.floor(Math.random() * 45) + 1;
    resultTextADD(r[0]);
    resultTextADD("\n");

    while (true) {
        r[1] = Math.floor(Math.random() * 45) + 1;
        if (r[0] != r[1]) {
            resultTextADD(r[1]);
            resultTextADD("\n");
            break;
        }
    }

    while (true) {
        r[2] = Math.floor(Math.random() * 45) + 1;
        if (r[2] != r[0] && r[2] != r[1]) {
            resultTextADD(r[2]);
            resultTextADD("\n");
            break;
        }
    }

    while (true) {
        r[3] = Math.floor(Math.random() * 45) + 1;
        if (r[3] != r[0] && r[3] != r[1] && r[3] != r[2]) {
            resultTextADD(r[3]);
            resultTextADD("\n");
            break;
        }
    }

    while (true) {
        r[4] = Math.floor(Math.random() * 45) + 1;
        if (r[4] != r[0] && r[4] != r[1] && r[4] != r[2] && r[4] != r[3]) {
            resultTextADD(r[4]);
            resultTextADD("\n");
            break;
        }
    }

    while (true) {
        r[5] = Math.floor(Math.random() * 45) + 1;
        if (r[5] != r[0] && r[5] != r[1] && r[5] != r[2] && r[5] != r[3] && r[5] != r[4]) {
            resultTextADD(r[5]);
            resultTextADD("\n");
            break;
        }
    }


    var b = 0;
    while(true) {
        b= Math.floor(Math.random() * 45) + 1;
        if (b != r[0] && b != r[1] && b != r[2] && b != r[3] && b != r[4] && b != r[5]){
            resultTextADD("보너스번호:"+b);
            resultTextADD("\n");
            break;
        }
    }

    var win = 0;

    for (var i = 0; i <= 5; i = i + 1) {
        for (var j = 0; j <= 5; j = j + 1) {
            if (p[i] == r[j]) {
                win = win + 1;
                winNumbers.push(r[j]);
            }
        }
    }

    resultTextADD("맞은 번호 갯수:" + win + "\n");

    var str = "";
    switch (win) {
        case 0:
        case 1:
        case 2:
            str = "꽝!!! 다음 기회에";
        case 3:
            str = "5등에 당첨되셨습니다.";
            break;
        case 4:
            str = "4등에 당첨되셨습니다.";
            break;
        case 5:
            str = "3등에 당첨되셨습니다.";
            for (var i = 0; i < 6; i = i + 1) {
                if (b == p[1]) {
                    str = "2등에 당첨되셨습니다.";
                }
            }
            break;
        case 6:
            str = "1등에 당첨되셨습니다.";
            break;
    }

    t.value = resultText;


    displayBall();
}


function displayBall() {
    var resultTags = "";
    for (var i = 0; i < 6; i = i + 1) {
        if (winNumbers.includes(parseInt(p[i]))) {
            resultTags = resultTags + "<div class='ball win'>" + p[i] + "</div>"
        } else {
            resultTags = resultTags + "<div class - 'ball'>" + p[i] + "</div>"
        }
    }
    tagResult.innerHTML = resultTags;
}